document.getElementById("userClick").onclick = function () {
        location.href = "/HTML//index.html";
}